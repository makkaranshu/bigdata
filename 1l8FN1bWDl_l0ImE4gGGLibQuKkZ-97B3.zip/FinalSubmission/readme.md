I have changed LoadCreateNoSQL.txt, so adding in this submission, created Hive HBase integrated table to connect with JAVA API.
Also, slight change in preAnalysis.txt, so adding that as well, used – Insert Overwrite option instead of insert.
